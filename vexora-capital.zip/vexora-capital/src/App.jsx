import { useState, useEffect, useRef, useCallback } from "react";

const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=DM+Sans:wght@300;400;500;600;700&family=Bebas+Neue&display=swap');
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --red:#c8102e; --red-b:#ff1a3a; --red-d:#8b0000; --red-g:rgba(200,16,46,0.4);
      --gold:#c9a84c; --gold-l:#f0c96a; --gold-d:#8b6914;
      --green:#00e676;
      --bg:#050505; --bg2:#0a0a0a; --bg3:#111; --bg4:#191919;
      --fg:#f5f5f0; --fg2:rgba(245,245,240,0.65); --fg3:rgba(245,245,240,0.06);
      --bdr:rgba(200,16,46,0.18); --bdr-b:rgba(200,16,46,0.5);
      --ff-d:'Playfair Display',serif; --ff-b:'DM Sans',sans-serif; --ff-s:'Bebas Neue',sans-serif;
      --nav:70px; --r:10px; --rl:16px;
    }
    html{scroll-behavior:smooth}
    body{background:var(--bg);color:var(--fg);font-family:var(--ff-b);min-height:100vh;overflow-x:hidden}
    ::-webkit-scrollbar{width:3px} ::-webkit-scrollbar-track{background:var(--bg2)} ::-webkit-scrollbar-thumb{background:var(--red-d);border-radius:2px}
    body::after{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.035'/%3E%3C/svg%3E");pointer-events:none;z-index:9998;opacity:.7}

    @keyframes fadeUp{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:translateY(0)}}
    @keyframes fadeIn{from{opacity:0}to{opacity:1}}
    @keyframes scaleIn{from{opacity:0;transform:scale(.93)}to{opacity:1;transform:scale(1)}}
    @keyframes slideLeft{from{transform:translateX(100%)}to{transform:translateX(0)}}
    @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
    @keyframes marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}
    @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
    @keyframes drawLine{from{stroke-dashoffset:800}to{stroke-dashoffset:0}}
    @keyframes pulseGreen{0%,100%{opacity:1}50%{opacity:.35}}
    @keyframes orbPulse{0%,100%{transform:scale(1);opacity:.6}50%{transform:scale(1.12);opacity:.9}}
    @keyframes toastIn{from{opacity:0;transform:translateX(120%)}to{opacity:1;transform:translateX(0)}}
    @keyframes toastOut{from{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(120%)}}
    @keyframes chartFade{from{opacity:0}to{opacity:1}}

    nav{position:fixed;top:0;left:0;right:0;z-index:200;height:var(--nav);display:flex;align-items:center;justify-content:space-between;padding:0 56px;background:rgba(5,5,5,.88);backdrop-filter:blur(24px) saturate(1.4);border-bottom:1px solid var(--bdr);transition:background .3s}
    .nav-scrolled{background:rgba(5,5,5,.97)!important}
    .nav-logo{display:flex;align-items:center;gap:10px;cursor:pointer}
    .logo-gem{width:38px;height:38px;background:linear-gradient(135deg,var(--red-d),var(--red),var(--red-b));border-radius:8px;display:flex;align-items:center;justify-content:center;font-family:var(--ff-s);font-size:22px;color:#fff;box-shadow:0 0 22px var(--red-g),inset 0 1px 0 rgba(255,255,255,.15)}
    .logo-wordmark{font-family:var(--ff-d);font-weight:700;font-size:19px;letter-spacing:.5px}
    .logo-wordmark em{font-style:normal;color:var(--red)}
    .nav-links{display:flex;gap:32px;list-style:none}
    .nav-links a{color:var(--fg2);text-decoration:none;font-size:12.5px;font-weight:500;letter-spacing:1.8px;text-transform:uppercase;transition:color .2s;position:relative}
    .nav-links a::after{content:'';position:absolute;bottom:-4px;left:0;width:0;height:1px;background:var(--red);transition:width .3s ease}
    .nav-links a:hover,.nav-links a.active{color:var(--fg)}
    .nav-links a:hover::after,.nav-links a.active::after{width:100%}
    .hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;background:none;border:none;padding:6px}
    .hamburger span{display:block;width:22px;height:1.5px;background:var(--fg);transition:all .3s}
    .mobile-drawer{position:fixed;inset:0;z-index:300;display:flex}
    .drawer-bg{flex:1;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);animation:fadeIn .25s ease}
    .drawer-panel{width:280px;background:var(--bg3);border-left:1px solid var(--bdr);padding:32px 24px;display:flex;flex-direction:column;gap:24px;animation:slideLeft .3s ease}
    .drawer-links{display:flex;flex-direction:column;gap:16px}
    .drawer-links a{color:var(--fg2);text-decoration:none;font-size:14px;letter-spacing:1.5px;text-transform:uppercase;font-weight:500;padding:10px 0;border-bottom:1px solid var(--bdr);transition:color .2s}
    .drawer-links a:hover{color:var(--fg)}
    .toast-stack{position:fixed;bottom:28px;right:28px;z-index:9000;display:flex;flex-direction:column;gap:10px}
    .toast{min-width:280px;max-width:340px;padding:14px 18px;border-radius:var(--r);background:var(--bg4);border:1px solid var(--bdr);display:flex;align-items:flex-start;gap:12px;box-shadow:0 8px 32px rgba(0,0,0,.6);animation:toastIn .4s ease;font-size:13.5px;line-height:1.5}
    .toast.exit{animation:toastOut .35s ease forwards}
    .toast-success{border-color:rgba(0,230,118,.35)} .toast-error{border-color:rgba(200,16,46,.5)} .toast-info{border-color:rgba(201,168,76,.4)}

    .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:none;border-radius:var(--r);cursor:pointer;font-family:var(--ff-b);font-weight:600;letter-spacing:1.2px;text-transform:uppercase;transition:all .3s ease;position:relative;overflow:hidden}
    .btn::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,transparent,rgba(255,255,255,.12),transparent);transform:translateX(-100%);transition:transform .45s ease}
    .btn:hover::before{transform:translateX(100%)}
    .btn-primary{background:linear-gradient(135deg,var(--red-d) 0%,var(--red) 50%,var(--red-b) 100%);color:#fff;font-size:13.5px;padding:13px 34px;box-shadow:0 4px 18px rgba(200,16,46,.25)}
    .btn-primary:hover{transform:translateY(-2px);box-shadow:0 10px 32px var(--red-g)}
    .btn-secondary{background:transparent;color:var(--fg);border:1px solid rgba(200,16,46,.4);font-size:13.5px;padding:12px 34px;backdrop-filter:blur(8px)}
    .btn-secondary:hover{border-color:var(--red);background:rgba(200,16,46,.08);transform:translateY(-2px)}
    .btn-gold{background:linear-gradient(135deg,var(--gold-d),var(--gold),var(--gold-l));color:#050505;font-size:13px;padding:12px 28px;width:100%;font-weight:700}
    .btn-gold:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(201,168,76,.45)}
    .btn-ghost{background:rgba(255,255,255,.04);color:var(--fg2);border:1px solid rgba(255,255,255,.08);font-size:12px;padding:9px 18px}
    .btn-ghost:hover{background:rgba(255,255,255,.08);color:var(--fg);border-color:rgba(255,255,255,.16)}
    .btn-sm{padding:9px 20px!important;font-size:12px!important} .btn-xs{padding:7px 16px!important;font-size:11px!important}
    .btn-full{width:100%} .btn-icon{width:36px;height:36px;padding:0!important;border-radius:8px;font-size:16px}
    .btn:disabled{opacity:.5;cursor:not-allowed;transform:none!important}

    .input{width:100%;background:rgba(255,255,255,.035);border:1px solid rgba(200,16,46,.18);border-radius:var(--r);padding:13px 16px;color:var(--fg);font-family:var(--ff-b);font-size:14px;transition:all .3s;outline:none;appearance:none}
    .input:focus{border-color:var(--red);background:rgba(200,16,46,.05);box-shadow:0 0 0 3px rgba(200,16,46,.1)}
    .input::placeholder{color:rgba(245,245,240,.25)}
    .input-label{font-size:11px;letter-spacing:1.8px;text-transform:uppercase;color:rgba(245,245,240,.45);display:block;margin-bottom:6px}
    .input-err{font-size:12px;color:var(--red-b);margin-top:5px}
    .input-group{display:flex;flex-direction:column}
    select.input{cursor:pointer} select.input option{background:var(--bg4)}

    .card{background:linear-gradient(145deg,rgba(22,6,6,.92),rgba(10,2,2,.96));border:1px solid var(--bdr);border-radius:var(--rl);position:relative;overflow:hidden;transition:border-color .3s,transform .3s,box-shadow .3s}
    .card::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(200,16,46,.55),transparent)}
    .card-glass{background:linear-gradient(145deg,rgba(255,255,255,.038),rgba(255,255,255,.012));backdrop-filter:blur(20px)}
    .card:hover{border-color:rgba(200,16,46,.45)}
    .card-glow:hover{box-shadow:0 16px 48px rgba(200,16,46,.18)}
    .card-lift:hover{transform:translateY(-6px)}

    .pill{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;letter-spacing:.5px}
    .pill-g{background:rgba(0,230,118,.1);color:var(--green);border:1px solid rgba(0,230,118,.2)}
    .pill-r{background:rgba(200,16,46,.1);color:var(--red-b);border:1px solid rgba(200,16,46,.25)}
    .pill-gold{background:rgba(201,168,76,.1);color:var(--gold-l);border:1px solid rgba(201,168,76,.25)}

    .section{padding:88px 60px} .section-sm{padding:56px 60px}
    .sec-label{font-family:var(--ff-s);letter-spacing:4px;font-size:12px;color:var(--red);text-transform:uppercase}
    .sec-title{font-family:var(--ff-d);font-size:clamp(30px,4vw,52px);font-weight:700;line-height:1.1}
    .sec-title em{font-style:normal;color:var(--red)}
    .sec-sub{color:var(--fg2);font-size:15px;line-height:1.75;margin-top:12px}

    .ticker-wrap{overflow:hidden;padding:9px 0;background:rgba(200,16,46,.07);border-top:1px solid var(--bdr);border-bottom:1px solid var(--bdr)}
    .ticker-track{display:flex;gap:56px;white-space:nowrap;animation:marquee 35s linear infinite}
    .ticker-item{font-family:var(--ff-s);font-size:12.5px;letter-spacing:2px;color:var(--fg2);display:flex;align-items:center;gap:8px}
    .t-sym{color:var(--red);font-weight:600} .up{color:var(--green)} .dn{color:var(--red-b)}

    .mesh{position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at 15% 60%,rgba(200,16,46,.07) 0%,transparent 55%),radial-gradient(ellipse at 85% 25%,rgba(139,0,0,.05) 0%,transparent 45%),radial-gradient(ellipse at 50% 90%,rgba(200,16,46,.04) 0%,transparent 40%)}
    .grid-lines{position:absolute;inset:0;pointer-events:none;background-image:linear-gradient(rgba(200,16,46,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(200,16,46,.025) 1px,transparent 1px);background-size:64px 64px}

    .plan-card{background:linear-gradient(165deg,rgba(20,5,5,.95),rgba(9,1,1,.98));border:1px solid rgba(200,16,46,.18);border-radius:var(--rl);padding:30px 24px 26px;position:relative;overflow:hidden;cursor:pointer;transition:all .4s cubic-bezier(.23,1,.32,1)}
    .plan-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--red),transparent);transform:scaleX(0);transform-origin:center;transition:transform .4s ease}
    .plan-card .cg{position:absolute;bottom:-70px;right:-70px;width:160px;height:160px;border-radius:50%;background:radial-gradient(circle,rgba(200,16,46,.14),transparent 70%);transition:all .45s ease}
    .plan-card:hover{border-color:rgba(200,16,46,.7);transform:translateY(-10px);box-shadow:0 24px 64px rgba(200,16,46,.22)}
    .plan-card:hover::before{transform:scaleX(1)}
    .plan-card:hover .cg{bottom:-20px;right:-20px}
    .plan-card.featured{border-color:rgba(201,168,76,.4);background:linear-gradient(165deg,rgba(25,14,2,.97),rgba(12,5,0,.99))}
    .plan-card.featured::before{background:linear-gradient(90deg,transparent,var(--gold),transparent);transform:scaleX(1)}
    .plan-card.featured:hover{border-color:rgba(201,168,76,.85);box-shadow:0 24px 64px rgba(201,168,76,.18)}

    .prog-track{height:3px;background:rgba(255,255,255,.06);border-radius:2px;overflow:hidden}
    .prog-fill{height:100%;border-radius:2px;background:linear-gradient(90deg,var(--red-d),var(--red-b));background-size:200% 100%;animation:shimmer 2.5s linear infinite}

    .tbl{width:100%;border-collapse:collapse;font-size:13.5px}
    .tbl th{text-align:left;padding:11px 16px;font-family:var(--ff-s);letter-spacing:2.5px;font-size:10.5px;color:var(--red);border-bottom:1px solid var(--bdr);background:rgba(200,16,46,.04);white-space:nowrap}
    .tbl td{padding:14px 16px;border-bottom:1px solid rgba(255,255,255,.032);color:var(--fg2);transition:all .2s}
    .tbl tr:hover td{background:rgba(200,16,46,.04);color:var(--fg)}
    .tbl tr:last-child td{border-bottom:none}
    .badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:10.5px;font-weight:600;letter-spacing:.8px}
    .b-paid{background:rgba(0,230,118,.1);color:var(--green);border:1px solid rgba(0,230,118,.22)}
    .b-pend{background:rgba(255,180,0,.1);color:#ffb400;border:1px solid rgba(255,180,0,.22)}
    .b-active{background:rgba(200,16,46,.1);color:var(--red-b);border:1px solid rgba(200,16,46,.25)}

    .dash-layout{display:grid;grid-template-columns:220px 1fr;min-height:calc(100vh - var(--nav))}
    .dash-side{background:var(--bg2);border-right:1px solid var(--bdr);padding:28px 0;display:flex;flex-direction:column;position:sticky;top:var(--nav);height:calc(100vh - var(--nav));overflow-y:auto}
    .side-hdr{padding:0 20px 20px;border-bottom:1px solid var(--bdr);margin-bottom:8px}
    .side-item{display:flex;align-items:center;gap:12px;padding:11px 20px;cursor:pointer;transition:all .2s;color:var(--fg2);font-size:13px;font-weight:500;border-left:2px solid transparent}
    .side-item:hover{background:rgba(200,16,46,.07);color:var(--fg);border-left-color:rgba(200,16,46,.4)}
    .side-item.active{background:rgba(200,16,46,.1);color:var(--fg);border-left-color:var(--red)}
    .side-item .ico{font-size:16px;width:20px;text-align:center;flex-shrink:0}
    .side-badge{margin-left:auto;background:var(--red);color:#fff;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px}
    .dash-main{padding:32px 36px;overflow-y:auto}
    .stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px}
    .stat-card{background:linear-gradient(145deg,rgba(22,5,5,.92),rgba(10,2,2,.96));border:1px solid var(--bdr);border-radius:var(--rl);padding:22px 22px 18px;transition:all .3s}
    .stat-card:hover{border-color:rgba(200,16,46,.45);box-shadow:0 8px 28px rgba(200,16,46,.1)}
    .sc-label{font-size:10.5px;letter-spacing:2px;text-transform:uppercase;color:rgba(245,245,240,.38);margin-bottom:10px;display:flex;align-items:center;gap:6px}
    .sc-val{font-family:var(--ff-s);font-size:30px;line-height:1;letter-spacing:1px}
    .sc-chg{font-size:11px;margin-top:6px;color:var(--fg2);display:flex;align-items:center;gap:4px}

    .modal-bg{position:fixed;inset:0;z-index:500;background:rgba(0,0,0,.75);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:20px;animation:fadeIn .25s ease}
    .modal{width:100%;max-width:480px;background:var(--bg3);border:1px solid var(--bdr);border-radius:var(--rl);overflow:hidden;animation:scaleIn .3s ease;box-shadow:0 32px 80px rgba(0,0,0,.8)}
    .modal-hdr{padding:22px 26px 18px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,rgba(200,16,46,.06),transparent)}
    .modal-body{padding:26px}
    .modal-ftr{padding:18px 26px;border-top:1px solid var(--bdr);display:flex;gap:10px;justify-content:flex-end}

    .testi{background:linear-gradient(145deg,rgba(18,4,4,.93),rgba(10,2,2,.97));border:1px solid var(--bdr);border-radius:var(--rl);padding:28px;position:relative;overflow:hidden}
    .testi::before{content:'"';position:absolute;top:12px;right:18px;font-family:var(--ff-d);font-size:90px;color:var(--red);opacity:.1;line-height:1;pointer-events:none}
    .stars{color:var(--gold);font-size:12px;letter-spacing:3px;margin-bottom:12px}
    .avatar{width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--red-d),var(--red));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:17px;flex-shrink:0;box-shadow:0 0 12px rgba(200,16,46,.35)}

    .faq-item{border:1px solid var(--bdr);border-radius:var(--r);overflow:hidden;margin-bottom:10px;transition:border-color .3s}
    .faq-item.open{border-color:rgba(200,16,46,.5)}
    .faq-q{width:100%;background:rgba(255,255,255,.018);border:none;color:var(--fg);padding:17px 20px;text-align:left;font-family:var(--ff-b);font-size:14.5px;font-weight:500;cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:16px;transition:background .2s;line-height:1.4}
    .faq-q:hover{background:rgba(200,16,46,.06)}
    .faq-icon{color:var(--red);font-size:20px;line-height:1;flex-shrink:0;transition:transform .3s}
    .faq-icon.open{transform:rotate(45deg)}
    .faq-a{background:rgba(200,16,46,.035);max-height:0;overflow:hidden;transition:max-height .4s ease,padding .3s;color:var(--fg2);font-size:14px;line-height:1.75}
    .faq-a.open{max-height:200px;padding:14px 20px 18px}

    .chart-line{stroke-dasharray:800;stroke-dashoffset:800;animation:drawLine 2.5s ease forwards .3s}
    .chart-area{animation:chartFade 1s ease forwards .8s;opacity:0}
    .spinner{display:inline-block;width:16px;height:16px;border:2px solid rgba(255,255,255,.25);border-top-color:#fff;border-radius:50%;animation:spin .75s linear infinite}
    .timeline{position:relative;padding-left:28px}
    .timeline::before{content:'';position:absolute;left:8px;top:0;bottom:0;width:1px;background:linear-gradient(to bottom,var(--red),transparent)}
    .tl-item{position:relative;margin-bottom:32px}
    .tl-dot{position:absolute;left:-24px;top:4px;width:10px;height:10px;border-radius:50%;background:var(--red);box-shadow:0 0 10px var(--red-g)}
    .tl-year{font-family:var(--ff-s);font-size:13px;color:var(--red);letter-spacing:2px;margin-bottom:4px}
    .tl-text{font-size:14px;color:var(--fg2);line-height:1.6}
    .ref-link{background:rgba(200,16,46,.06);border:1px solid rgba(200,16,46,.25);border-radius:var(--r);padding:12px 16px;font-size:12.5px;color:var(--red-b);word-break:break-all;font-family:monospace}
    #pcanvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0}

    /* ── MOBILE BOTTOM TAB BAR ── */
    .mob-tabs{display:none;position:fixed;bottom:0;left:0;right:0;z-index:150;background:var(--bg3);border-top:1px solid var(--bdr);padding:6px 0 max(6px,env(safe-area-inset-bottom));gap:0}
    .mob-tab{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px 4px;cursor:pointer;transition:color .2s;color:var(--fg2);font-size:9px;letter-spacing:.8px;text-transform:uppercase;background:none;border:none;font-family:var(--ff-b)}
    .mob-tab .mt-ic{font-size:20px;line-height:1}
    .mob-tab.active{color:var(--red)}
    @media(max-width:1024px){.mob-tabs{display:flex}}
    @media(max-width:1024px){.dash-main{padding-bottom:80px}}

    /* ── MOBILE RESPONSIVE ── */
    @media(max-width:1024px){
      .dash-layout{grid-template-columns:1fr}
      .dash-side{display:none}
      .stat-grid{grid-template-columns:repeat(2,1fr)}
    }
    @media(max-width:768px){
      nav{padding:0 16px}
      .nav-links{display:none}
      .hamburger{display:flex}
      .section,.section-sm{padding:52px 20px}
      .dash-main{padding:16px 14px}
      .stat-grid{grid-template-columns:repeat(2,1fr);gap:10px}
      .toast-stack{bottom:76px;right:12px;left:12px}
      .toast{min-width:0;max-width:100%}
      .modal{margin:12px}
      .modal-body{padding:20px 18px}
      .modal-hdr{padding:18px 20px 14px}
      .modal-ftr{padding:14px 18px}
      .plan-card{padding:24px 20px 20px}
      .tbl th,.tbl td{padding:10px 12px;font-size:12px}
      .faq-q{font-size:13.5px;padding:14px 16px}
      .testi{padding:22px 20px}
      .testi::before{font-size:60px}
      .drawer-panel{width:260px}
    }
    @media(max-width:480px){
      .stat-grid{grid-template-columns:1fr}
      nav{padding:0 14px}
      .btn-primary,.btn-secondary{padding:12px 24px;font-size:13px}
      .logo-wordmark{font-size:16px}
      .logo-gem{width:32px;height:32px;font-size:18px}
    }
  `}</style>
);

const PLANS = [
  {name:"Starter",   invest:100,   earn:1500,  icon:"◈",tier:1},
  {name:"Bronze",    invest:300,   earn:3600,  icon:"◉",tier:2},
  {name:"Silver",    invest:500,   earn:6000,  icon:"◈",tier:3},
  {name:"Gold",      invest:700,   earn:8400,  icon:"◆",tier:4,featured:true},
  {name:"Premium",   invest:1000,  earn:12000, icon:"◈",tier:5},
  {name:"Executive", invest:2000,  earn:25500, icon:"◉",tier:6},
  {name:"VIP",       invest:5000,  earn:75300, icon:"★",tier:7,featured:true},
];

const PAYOUTS = [
  {name:"Jam**son R.",country:"🇺🇸 USA",         inv:"$2,000",rcv:"$25,500",date:"Jun 07, 2026",s:"paid"},
  {name:"Soph**a M.", country:"🇬🇧 UK",           inv:"$5,000",rcv:"$75,300",date:"Jun 07, 2026",s:"paid"},
  {name:"Kev**n L.",  country:"🇨🇦 Canada",       inv:"$1,000",rcv:"$12,000",date:"Jun 06, 2026",s:"paid"},
  {name:"Ami**a T.",  country:"🇳🇬 Nigeria",      inv:"$700",  rcv:"$8,400", date:"Jun 06, 2026",s:"paid"},
  {name:"Marc**s B.", country:"🇩🇪 Germany",      inv:"$500",  rcv:"$6,000", date:"Jun 06, 2026",s:"paid"},
  {name:"Priy**a S.", country:"🇮🇳 India",        inv:"$300",  rcv:"$3,600", date:"Jun 05, 2026",s:"paid"},
  {name:"Tho**as W.", country:"🇦🇺 Australia",    inv:"$2,000",rcv:"$25,500",date:"Jun 05, 2026",s:"paid"},
  {name:"Ade**la F.", country:"🇿🇦 South Africa", inv:"$100",  rcv:"$1,500", date:"Jun 05, 2026",s:"paid"},
  {name:"Ri**ard O.", country:"🇫🇷 France",       inv:"$5,000",rcv:"$75,300",date:"Jun 04, 2026",s:"paid"},
  {name:"Chi**ma N.", country:"🇳🇬 Nigeria",      inv:"$1,000",rcv:"$12,000",date:"Jun 04, 2026",s:"paid"},
  {name:"Ol**a B.",   country:"🇺🇦 Ukraine",      inv:"$700",  rcv:"$8,400", date:"Jun 04, 2026",s:"paid"},
  {name:"San**ra K.", country:"🇰🇷 South Korea",  inv:"$500",  rcv:"$6,000", date:"Jun 07, 2026",s:"pending"},
  {name:"Luc**s P.",  country:"🇧🇷 Brazil",       inv:"$2,000",rcv:"$25,500",date:"Jun 07, 2026",s:"pending"},
  {name:"Ye**n G.",   country:"🇨🇳 China",        inv:"$1,000",rcv:"$12,000",date:"Jun 03, 2026",s:"paid"},
  {name:"Emi**y D.",  country:"🇺🇸 USA",          inv:"$300",  rcv:"$3,600", date:"Jun 03, 2026",s:"paid"},
  {name:"Mo**za A.",  country:"🇲🇦 Morocco",      inv:"$5,000",rcv:"$75,300",date:"Jun 02, 2026",s:"paid"},
];

const TICKERS=[
  {sym:"BTC",val:"$67,420",chg:"+2.4%",up:true},{sym:"ETH",val:"$3,812",chg:"+1.8%",up:true},
  {sym:"GOLD",val:"$2,341/oz",chg:"+0.6%",up:true},{sym:"S&P 500",val:"5,847",chg:"+0.9%",up:true},
  {sym:"NASDAQ",val:"18,923",chg:"+1.2%",up:true},{sym:"VEX INDEX",val:"924.3",chg:"+3.1%",up:true},
  {sym:"OIL",val:"$78.42",chg:"-0.3%",up:false},{sym:"EUR/USD",val:"1.084",chg:"+0.1%",up:true},
  {sym:"BNB",val:"$618",chg:"+2.9%",up:true},{sym:"SILVER",val:"$29.80",chg:"-0.2%",up:false},
];

const FAQS=[
  {q:"How do I start investing with Vexora Capital?",a:"Register an account, select your plan, deposit funds, and your investment begins immediately. Returns are credited automatically weekly."},
  {q:"When will I receive my returns?",a:"Returns are processed weekly. Once your investment matures, funds appear in your dashboard and can be withdrawn within 24–48 hours."},
  {q:"Is my investment and personal data secure?",a:"Yes. Vexora Capital uses 256-bit AES encryption, multi-factor authentication, and cold storage protocols. Fully compliant with international financial data regulations."},
  {q:"What is the minimum deposit amount?",a:"Our Starter Plan begins at just $100, making premium investment opportunities accessible to everyone."},
  {q:"How do withdrawals work?",a:"Withdrawals are processed within 24–48 hours to your registered account. No minimum withdrawal limit or hidden fees."},
  {q:"Is there a referral program?",a:"Yes! Earn 5% commission on every investment made by users you refer. Commissions are paid instantly to your dashboard balance."},
  {q:"Can I hold multiple plans simultaneously?",a:"Yes. You may hold multiple active investments across different tiers. Each plan runs independently with separate returns credited weekly."},
];

const TESTIMONIALS=[
  {name:"James R.",role:"Entrepreneur — USA",text:"I was cautious at first, but Vexora Capital exceeded every expectation. My Gold Plan matured on schedule and the $8,400 payout hit within 24 hours.",rating:5},
  {name:"Amara T.",role:"Business Owner — UK",text:"The Silver Plan was my entry point and I couldn't be more impressed. Transparent returns, fast withdrawals, and outstanding professional support throughout.",rating:5},
  {name:"Marcus B.",role:"Portfolio Manager — Germany",text:"After 12 years in investment, Vexora Capital is the most transparent platform I've used. My VIP plan result of $75,300 speaks for itself.",rating:5},
  {name:"Priya S.",role:"Tech Professional — India",text:"Started with Bronze, amazed by results. Now running Executive and VIP simultaneously. The 5% referral commission is an excellent bonus income stream.",rating:5},
];

function useToast(){
  const [toasts,setToasts]=useState([]);
  const add=useCallback((msg,type="info",dur=4000)=>{
    const id=Date.now();
    setToasts(t=>[...t,{id,msg,type}]);
    setTimeout(()=>{setToasts(t=>t.map(x=>x.id===id?{...x,exiting:true}:x));setTimeout(()=>setToasts(t=>t.filter(x=>x.id!==id)),380);},dur);
  },[]);
  return{toasts,add};
}

function ToastStack({toasts}){
  const ic={success:"✅",error:"🚨",info:"💡",warning:"⚠️"};
  return(
    <div className="toast-stack">
      {toasts.map(t=>(
        <div key={t.id} className={`toast toast-${t.type}${t.exiting?" exit":""}`}>
          <span style={{fontSize:18,flexShrink:0}}>{ic[t.type]||"💡"}</span>
          <span style={{color:"var(--fg)"}}>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

function Logo({onClick}){
  return(
    <div className="nav-logo" onClick={onClick}>
      <div className="logo-gem">V</div>
      <span className="logo-wordmark">Vexora <em>Capital</em></span>
    </div>
  );
}

function Ticker(){
  const items=[...TICKERS,...TICKERS];
  return(
    <div className="ticker-wrap">
      <div className="ticker-track">
        {items.map((t,i)=>(
          <div key={i} className="ticker-item">
            <span className="t-sym">{t.sym}</span>
            <span>{t.val}</span>
            <span className={t.up?"up":"dn"}>{t.chg}</span>
            <span style={{opacity:.15}}>|</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AnimNumber({value,prefix="",suffix="",dur=2000}){
  const [n,setN]=useState(0);
  const ref=useRef(null);
  const done=useRef(false);
  useEffect(()=>{
    const obs=new IntersectionObserver(([e])=>{
      if(e.isIntersecting&&!done.current){
        done.current=true;
        const t0=performance.now();
        const tick=now=>{
          const t=Math.min((now-t0)/dur,1);
          const ease=1-Math.pow(1-t,3);
          setN(Math.floor(ease*value));
          if(t<1)requestAnimationFrame(tick);else setN(value);
        };
        requestAnimationFrame(tick);
        obs.disconnect();
      }
    },{threshold:.3});
    if(ref.current)obs.observe(ref.current);
    return()=>obs.disconnect();
  },[value,dur]);
  return(
    <span ref={ref} style={{fontFamily:"var(--ff-s)",fontSize:44,background:"linear-gradient(135deg,var(--fg),var(--gold-l))",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text",lineHeight:1}}>
      {prefix}{n.toLocaleString()}{suffix}
    </span>
  );
}

function GrowthChart({w=320,h=130}){
  const pts=[12,28,22,48,38,62,54,74,68,85,78,100];
  const pad=14,xS=(w-pad*2)/(pts.length-1),yS=(h-pad*2)/100;
  const line=pts.map((p,i)=>`${i===0?"M":"L"}${(pad+i*xS).toFixed(1)},${(h-pad-p*yS).toFixed(1)}`).join(" ");
  const area=line+` L${(pad+(pts.length-1)*xS).toFixed(1)},${h-pad} L${pad},${h-pad} Z`;
  return(
    <svg viewBox={`0 0 ${w} ${h}`} style={{width:"100%",maxWidth:w,display:"block"}}>
      <defs>
        <linearGradient id="ag" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#c8102e" stopOpacity=".45"/><stop offset="100%" stopColor="#c8102e" stopOpacity="0"/></linearGradient>
        <filter id="gl"><feGaussianBlur stdDeviation="2" result="b"/><feComposite in="SourceGraphic" in2="b" operator="over"/></filter>
        <linearGradient id="lg" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#8b0000"/><stop offset="100%" stopColor="#ff1a3a"/></linearGradient>
      </defs>
      {[25,50,75].map(v=><line key={v} x1={pad} y1={h-pad-v*yS} x2={w-pad} y2={h-pad-v*yS} stroke="rgba(200,16,46,.08)" strokeWidth="1" strokeDasharray="4,4"/>)}
      <path d={area} fill="url(#ag)" className="chart-area"/>
      <path d={line} fill="none" stroke="url(#lg)" strokeWidth="2.5" filter="url(#gl)" className="chart-line" strokeLinecap="round" strokeLinejoin="round"/>
      {pts.filter((_,i)=>i%3===0).map((p,i)=><circle key={i} cx={pad+i*3*xS} cy={h-pad-p*yS} r="3.5" fill="#ff1a3a" opacity=".85"/>)}
    </svg>
  );
}

function DonutChart({pct=72,size=90}){
  const r=34,c=2*Math.PI*r,f=c*(pct/100);
  return(
    <svg width={size} height={size} viewBox="0 0 90 90">
      <circle cx="45" cy="45" r={r} fill="none" stroke="rgba(200,16,46,.1)" strokeWidth="7"/>
      <circle cx="45" cy="45" r={r} fill="none" stroke="url(#dg)" strokeWidth="7" strokeDasharray={`${f} ${c}`} strokeLinecap="round" transform="rotate(-90 45 45)"/>
      <defs><linearGradient id="dg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#8b0000"/><stop offset="100%" stopColor="#ff1a3a"/></linearGradient></defs>
      <text x="45" y="49" textAnchor="middle" fill="#f5f5f0" fontSize="14" fontFamily="'Bebas Neue'" letterSpacing="1">{pct}%</text>
    </svg>
  );
}

function Particles(){
  const ref=useRef(null);
  useEffect(()=>{
    const cv=ref.current;if(!cv)return;
    const ctx=cv.getContext("2d");
    let W,H,pts=[],raf;
    const resize=()=>{W=cv.width=cv.offsetWidth;H=cv.height=cv.offsetHeight;};
    resize();window.addEventListener("resize",resize);
    for(let i=0;i<55;i++)pts.push({x:Math.random()*1400,y:Math.random()*800,vx:(Math.random()-.5)*.3,vy:(Math.random()-.5)*.3,r:Math.random()*1.4+.4,a:Math.random()});
    const draw=()=>{
      ctx.clearRect(0,0,W,H);
      pts.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.x<0)p.x=W;if(p.x>W)p.x=0;if(p.y<0)p.y=H;if(p.y>H)p.y=0;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(200,16,46,${p.a*.55})`;ctx.fill();});
      pts.forEach((p,i)=>pts.slice(i+1).forEach(q=>{const d=Math.hypot(p.x-q.x,p.y-q.y);if(d<110){ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.strokeStyle=`rgba(200,16,46,${.12*(1-d/110)})`;ctx.lineWidth=.6;ctx.stroke();}}));
      raf=requestAnimationFrame(draw);
    };
    draw();
    return()=>{cancelAnimationFrame(raf);window.removeEventListener("resize",resize);};
  },[]);
  return <canvas ref={ref} id="pcanvas"/>;
}

function Modal({title,onClose,children,footer}){
  useEffect(()=>{const h=e=>e.key==="Escape"&&onClose();window.addEventListener("keydown",h);return()=>window.removeEventListener("keydown",h);},[onClose]);
  return(
    <div className="modal-bg" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal">
        <div className="modal-hdr">
          <div style={{fontFamily:"var(--ff-d)",fontSize:20,fontWeight:700}}>{title}</div>
          <button onClick={onClose} style={{background:"none",border:"none",color:"var(--fg2)",cursor:"pointer",fontSize:20,lineHeight:1,padding:4}}>✕</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer&&<div className="modal-ftr">{footer}</div>}
      </div>
    </div>
  );
}

function DepositModal({onClose,onSuccess}){
  const [plan,setPlan]=useState("");
  const [method,setMethod]=useState("");
  const [loading,setLoading]=useState(false);
  const go=()=>{if(!plan||!method)return;setLoading(true);setTimeout(()=>{onSuccess(plan);onClose();},1600);};
  const sel=PLANS.find(x=>x.name===plan);
  return(
    <Modal title="Make a Deposit" onClose={onClose}
      footer={<><button className="btn btn-ghost btn-sm" onClick={onClose}>Cancel</button><button className="btn btn-primary btn-sm" onClick={go} disabled={loading}>{loading?<><span className="spinner"/>&nbsp;Processing…</>:"Confirm Deposit"}</button></>}>
      <div style={{display:"flex",flexDirection:"column",gap:16}}>
        <div className="input-group">
          <label className="input-label">Select Investment Plan</label>
          <select className="input" value={plan} onChange={e=>setPlan(e.target.value)}>
            <option value="">— Choose a plan —</option>
            {PLANS.map(p=><option key={p.name} value={p.name}>{p.name} Plan — Invest ${p.invest.toLocaleString()} → Earn ${p.earn.toLocaleString()}</option>)}
          </select>
        </div>
        <div className="input-group">
          <label className="input-label">Payment Method</label>
          <select className="input" value={method} onChange={e=>setMethod(e.target.value)}>
            <option value="">— Choose method —</option>
            <option>Bitcoin (BTC)</option><option>Ethereum (ETH)</option><option>USDT (TRC20)</option><option>Bank Transfer</option>
          </select>
        </div>
        {sel&&(
          <div style={{background:"rgba(200,16,46,.06)",border:"1px solid var(--bdr)",borderRadius:8,padding:"14px 16px"}}>
            <div style={{fontSize:11,letterSpacing:2,color:"var(--fg2)",marginBottom:8}}>ORDER SUMMARY</div>
            <div style={{display:"flex",justifyContent:"space-between"}}>
              <div><div style={{fontSize:12,color:"var(--fg2)"}}>You Invest</div><div style={{fontFamily:"var(--ff-s)",fontSize:24}}>${sel.invest.toLocaleString()}</div></div>
              <div style={{textAlign:"right"}}><div style={{fontSize:12,color:"var(--fg2)"}}>You Earn</div><div style={{fontFamily:"var(--ff-s)",fontSize:24,color:"var(--green)"}}>${sel.earn.toLocaleString()}</div></div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}

function WithdrawModal({balance,onClose,onSuccess}){
  const [amount,setAmount]=useState("");
  const [method,setMethod]=useState("");
  const [addr,setAddr]=useState("");
  const [loading,setLoading]=useState(false);
  const go=()=>{if(!amount||!method||!addr||Number(amount)>balance)return;setLoading(true);setTimeout(()=>{onSuccess(Number(amount));onClose();},1800);};
  return(
    <Modal title="Withdraw Funds" onClose={onClose}
      footer={<><button className="btn btn-ghost btn-sm" onClick={onClose}>Cancel</button><button className="btn btn-primary btn-sm" onClick={go} disabled={loading}>{loading?<><span className="spinner"/>&nbsp;Processing…</>:"Confirm Withdrawal"}</button></>}>
      <div style={{display:"flex",flexDirection:"column",gap:14}}>
        <div style={{display:"flex",justifyContent:"space-between",background:"rgba(0,230,118,.06)",border:"1px solid rgba(0,230,118,.15)",borderRadius:8,padding:"12px 16px"}}>
          <span style={{fontSize:13,color:"var(--fg2)"}}>Available Balance</span>
          <span style={{fontFamily:"var(--ff-s)",fontSize:20,color:"var(--green)"}}>${balance.toLocaleString()}</span>
        </div>
        <div className="input-group"><label className="input-label">Amount (USD)</label><input className="input" type="number" placeholder="Enter amount" value={amount} onChange={e=>setAmount(e.target.value)} min="10" max={balance}/></div>
        <div className="input-group"><label className="input-label">Withdrawal Method</label><select className="input" value={method} onChange={e=>setMethod(e.target.value)}><option value="">— Choose method —</option><option>Bitcoin (BTC)</option><option>Ethereum (ETH)</option><option>USDT (TRC20)</option><option>Bank Transfer</option></select></div>
        <div className="input-group"><label className="input-label">Wallet / Account Address</label><input className="input" placeholder="Enter wallet address or account number" value={addr} onChange={e=>setAddr(e.target.value)}/></div>
      </div>
    </Modal>
  );
}

function PlanCard({plan,onInvest}){
  return(
    <div className={`plan-card${plan.featured?" featured":""}`}>
      {plan.featured&&<div style={{position:"absolute",top:14,right:14,background:"linear-gradient(135deg,var(--gold-d),var(--gold))",color:"#050505",fontSize:9,fontWeight:800,letterSpacing:2,padding:"3px 9px",borderRadius:20}}>POPULAR</div>}
      <div className="cg"/>
      <div style={{fontSize:22,marginBottom:12,color:plan.featured?"var(--gold)":"var(--red)"}}>{plan.icon}</div>
      <div style={{fontFamily:"var(--ff-s)",fontSize:21,letterSpacing:2.5,marginBottom:2}}>{plan.name}</div>
      <div style={{fontSize:11,color:"var(--fg2)",letterSpacing:1.5,marginBottom:18}}>INVESTMENT PLAN</div>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
        <div><div style={{fontSize:10,color:"var(--fg2)",letterSpacing:1,marginBottom:2}}>INVEST</div><div style={{fontFamily:"var(--ff-s)",fontSize:26}}>${plan.invest.toLocaleString()}</div></div>
        <div style={{textAlign:"right"}}><div style={{fontSize:10,color:"var(--fg2)",letterSpacing:1,marginBottom:2}}>EARN</div><div style={{fontFamily:"var(--ff-s)",fontSize:26,color:plan.featured?"var(--gold-l)":"var(--green)"}}>${plan.earn.toLocaleString()}</div></div>
      </div>
      <div className="prog-track" style={{marginBottom:14}}><div className="prog-fill" style={{width:`${(plan.tier/7)*100}%`}}/></div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
        <span style={{fontSize:12,color:"var(--fg2)"}}>Profit ratio</span>
        <span className={`pill ${plan.featured?"pill-gold":"pill-g"}`}>+{Math.round(((plan.earn-plan.invest)/plan.invest)*100)}%</span>
      </div>
      <button className={plan.featured?"btn btn-gold":"btn btn-primary"} onClick={onInvest} style={{fontSize:12,padding:"11px 16px",width:"100%"}}>Invest Now →</button>
    </div>
  );
}

function LandingPage({setPage}){
  const [faq,setFaq]=useState(null);
  return(
    <div>
      {/* HERO */}
      <section style={{position:"relative",minHeight:"calc(100vh - 70px)",display:"flex",flexDirection:"column",justifyContent:"center",padding:"clamp(60px,8vw,80px) clamp(16px,5vw,60px) 48px",overflow:"hidden"}}>
        <Particles/>
        <div className="mesh"/>
        <div className="grid-lines"/>
        <div style={{position:"absolute",right:"5%",top:"50%",transform:"translateY(-50%)",width:"min(520px,60vw)",height:"min(520px,60vw)",background:"radial-gradient(circle,rgba(200,16,46,.1) 0%,transparent 68%)",borderRadius:"50%",pointerEvents:"none",animation:"orbPulse 6s ease infinite"}}/>
        <div style={{maxWidth:1200,margin:"0 auto",width:"100%",display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,420px),1fr))",gap:"clamp(28px,5vw,64px)",alignItems:"center",position:"relative",zIndex:1}}>
          <div style={{animation:"fadeUp .9s ease both"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}>
              <div style={{height:1,width:28,background:"var(--red)",flexShrink:0}}/>
              <span className="sec-label">Premium Global Investment Platform</span>
            </div>
            <h1 style={{fontFamily:"var(--ff-d)",fontWeight:900,fontSize:"clamp(32px,6vw,62px)",lineHeight:1.08,marginBottom:18}}>
              Secure Your Future<br/>With <span style={{color:"var(--red)"}}>Smart</span><br/>Investments
            </h1>
            <p style={{color:"var(--fg2)",fontSize:"clamp(14px,2vw,16px)",lineHeight:1.8,marginBottom:28,maxWidth:460}}>
              Join a growing community of investors building real wealth through premium, transparent investment opportunities. Powered by expertise. Built on trust.
            </p>
            <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:32}}>
              <button className="btn btn-primary" onClick={()=>setPage("register")} style={{padding:"13px clamp(22px,4vw,40px)",fontSize:13,flex:"1 1 140px",maxWidth:220}}>Start Investing</button>
              <button className="btn btn-secondary" onClick={()=>setPage("payouts")} style={{padding:"12px clamp(22px,4vw,40px)",fontSize:13,flex:"1 1 140px",maxWidth:220}}>View Payouts</button>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:"8px 20px"}}>
              {[["🔒","Bank-Grade Security"],["⚡","24h Withdrawals"],["🌍","89 Countries"],["🏆","$18M+ Paid Out"]].map(([ic,lb])=>(
                <div key={lb} style={{display:"flex",alignItems:"center",gap:7,color:"var(--fg2)",fontSize:12}}><span style={{fontSize:15}}>{ic}</span><span>{lb}</span></div>
              ))}
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12,animation:"fadeUp .9s ease .18s both"}}>
            <div className="card card-glass" style={{padding:"20px 22px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14,flexWrap:"wrap",gap:8}}>
                <div><div style={{fontSize:11,color:"var(--fg2)",letterSpacing:2,marginBottom:3}}>PORTFOLIO GROWTH</div><div style={{fontFamily:"var(--ff-s)",fontSize:28,color:"var(--green)",lineHeight:1}}>+754%</div></div>
                <span className="pill pill-g" style={{fontSize:10}}>↑ +$12,840 this month</span>
              </div>
              <GrowthChart w={340} h={110}/>
              <div style={{display:"flex",justifyContent:"space-between",marginTop:10,fontSize:10,color:"var(--fg2)"}}>
                {["Jan","Feb","Mar","Apr","May","Jun"].map(m=><span key={m}>{m}</span>)}
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {[{l:"Active Investors",v:24700,s:"+"},{l:"Total Paid Out",v:18,p:"$",s:"M+"},{l:"Countries",v:89,s:"+"},{l:"Success Rate",v:99,s:"%"}].map(({l,v,p="",s})=>(
                <div key={l} className="card card-glass" style={{padding:"14px 16px",textAlign:"center"}}>
                  <AnimNumber value={v} prefix={p} suffix={s}/>
                  <div style={{fontSize:10,color:"var(--fg2)",marginTop:4,letterSpacing:1}}>{l}</div>
                </div>
              ))}
            </div>
            <div className="card" style={{padding:"12px 16px",display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:8,height:8,borderRadius:"50%",background:"var(--green)",animation:"pulseGreen 1.3s ease infinite",flexShrink:0}}/>
              <div style={{fontSize:12,color:"var(--fg2)",lineHeight:1.4}}><span style={{color:"var(--fg)",fontWeight:600}}>Soph**a M.</span> from 🇬🇧 UK just received <span style={{color:"var(--green)",fontWeight:600}}>$75,300</span></div>
            </div>
          </div>
        </div>
      </section>

      <Ticker/>

      {/* WHY CHOOSE US */}
      <section className="section" style={{position:"relative",background:"rgba(0,0,0,.22)"}}>
        <div className="grid-lines"/>
        <div style={{maxWidth:1200,margin:"0 auto",position:"relative"}}>
          <div style={{textAlign:"center",marginBottom:"clamp(32px,5vw,56px)"}}>
            <div className="sec-label" style={{marginBottom:12}}>◈ Our Advantages</div>
            <h2 className="sec-title">Why Choose <em>Vexora Capital</em></h2>
            <p className="sec-sub" style={{maxWidth:500,margin:"12px auto 0"}}>Built for serious investors who demand transparency, security, and real returns.</p>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,200px),1fr))",gap:14}}>
            {[{ic:"🛡",t:"Secure Platform",d:"256-bit AES encryption, multi-layer auth, and cold storage on all funds."},{ic:"⚡",t:"Fast Withdrawals",d:"Funds delivered within 24–48 hours. No delays, no excuses."},{ic:"📈",t:"Proven Returns",d:"Consistent, verified returns across all plan tiers since our founding."},{ic:"🌍",t:"Global Community",d:"24,700+ active investors across 89 countries trust Vexora Capital daily."},{ic:"💬",t:"24/7 Support",d:"Professional support via live chat, email, and phone — around the clock."}].map(({ic,t,d})=>(
              <div key={t} className="card card-glow card-lift" style={{padding:"clamp(18px,3vw,28px)",cursor:"default"}}>
                <div style={{width:44,height:44,background:"rgba(200,16,46,.12)",border:"1px solid var(--bdr)",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,marginBottom:14}}>{ic}</div>
                <div style={{fontFamily:"var(--ff-d)",fontWeight:700,fontSize:16,marginBottom:8}}>{t}</div>
                <div style={{color:"var(--fg2)",fontSize:13,lineHeight:1.7}}>{d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PLANS PREVIEW */}
      <section className="section" style={{position:"relative"}}>
        <div className="mesh"/>
        <div style={{maxWidth:1200,margin:"0 auto",position:"relative"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:"clamp(28px,4vw,48px)",flexWrap:"wrap",gap:14}}>
            <div><div className="sec-label" style={{marginBottom:10}}>◈ Investment Tiers</div><h2 className="sec-title">Choose Your <em>Plan</em></h2></div>
            <button className="btn btn-secondary btn-sm" onClick={()=>setPage("plans")}>View All Plans →</button>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(min(100%,220px),1fr))",gap:14}}>
            {PLANS.map(p=><PlanCard key={p.name} plan={p} onInvest={()=>setPage("register")}/>)}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section" style={{background:"rgba(0,0,0,.25)"}}>
        <div style={{maxWidth:1200,margin:"0 auto"}}>
          <div style={{textAlign:"center",marginBottom:"clamp(28px,4vw,48px)"}}>
            <div className="sec-label" style={{marginBottom:12}}>◈ Investor Stories</div>
            <h2 className="sec-title">What Our Investors <em>Say</em></h2>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,260px),1fr))",gap:16}}>
            {TESTIMONIALS.map(t=>(
              <div key={t.name} className="testi">
                <div className="stars">{"★".repeat(t.rating)}</div>
                <p style={{color:"var(--fg2)",fontSize:14,lineHeight:1.8,marginBottom:18}}>{t.text}</p>
                <div style={{display:"flex",alignItems:"center",gap:12}}>
                  <div className="avatar">{t.name[0]}</div>
                  <div><div style={{fontWeight:600,fontSize:14}}>{t.name}</div><div style={{fontSize:12,color:"var(--fg2)"}}>{t.role}</div></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section">
        <div style={{maxWidth:820,margin:"0 auto"}}>
          <div style={{textAlign:"center",marginBottom:48}}>
            <div className="sec-label" style={{marginBottom:12}}>◈ Common Questions</div>
            <h2 className="sec-title">Frequently Asked <em>Questions</em></h2>
          </div>
          {FAQS.map((f,i)=>(
            <div key={i} className={`faq-item${faq===i?" open":""}`}>
              <button className="faq-q" onClick={()=>setFaq(faq===i?null:i)}>
                <span>{f.q}</span>
                <span className={`faq-icon${faq===i?" open":""}`}>+</span>
              </button>
              <div className={`faq-a${faq===i?" open":""}`}>{f.a}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACT */}
      <section className="section" style={{background:"rgba(0,0,0,.25)"}}>
        <div style={{maxWidth:1200,margin:"0 auto"}}>
          <div style={{textAlign:"center",marginBottom:"clamp(28px,4vw,48px)"}}>
            <div className="sec-label" style={{marginBottom:12}}>◈ Reach Us</div>
            <h2 className="sec-title">Get In <em>Touch</em></h2>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,320px),1fr))",gap:"clamp(20px,4vw,40px)"}}>
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              {[{ic:"✉",l:"Email",v:"support@vexoracapital.com"},{ic:"📞",l:"Phone",v:"+1 (800) 839-2671"},{ic:"💬",l:"Live Chat",v:"Available 24/7 in dashboard"},{ic:"📍",l:"HQ",v:"Financial District, New York, NY 10005"}].map(({ic,l,v})=>(
                <div key={l} className="card" style={{padding:"16px 18px",display:"flex",alignItems:"center",gap:14}}>
                  <div style={{width:40,height:40,background:"rgba(200,16,46,.1)",border:"1px solid var(--bdr)",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{ic}</div>
                  <div><div style={{fontSize:10,letterSpacing:2,color:"var(--fg2)",marginBottom:2}}>{l.toUpperCase()}</div><div style={{fontWeight:500,fontSize:13}}>{v}</div></div>
                </div>
              ))}
            </div>
            <div className="card" style={{padding:"clamp(20px,4vw,28px)"}}>
              <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:18}}>SEND A MESSAGE</div>
              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                <input className="input" placeholder="Full Name"/>
                <input className="input" type="email" placeholder="Email Address"/>
                <input className="input" placeholder="Subject"/>
                <textarea className="input" placeholder="Your message…" rows={4} style={{resize:"none"}}/>
                <button className="btn btn-primary btn-full">Send Message</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{background:"var(--bg2)",borderTop:"1px solid var(--bdr)",padding:"clamp(32px,5vw,52px) clamp(16px,5vw,60px) 24px"}}>
        <div style={{maxWidth:1200,margin:"0 auto"}}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,160px),1fr))",gap:"clamp(24px,4vw,44px)",marginBottom:"clamp(28px,4vw,44px)"}}>
            <div style={{gridColumn:"1 / -1",maxWidth:340}}>
              <Logo onClick={()=>{}}/>
              <p style={{color:"var(--fg2)",fontSize:13,lineHeight:1.8,marginTop:14,maxWidth:290}}>
                Vexora Capital connects investors worldwide with premium opportunities and consistent, transparent returns.
              </p>
              <div style={{display:"flex",gap:8,marginTop:18,flexWrap:"wrap"}}>
                {["𝕏","f","in","✈","▶"].map((s,i)=><button key={i} className="btn btn-ghost btn-icon" style={{fontSize:13}}>{s}</button>)}
              </div>
            </div>
            {[
              {t:"Platform",ls:["Home","Investment Plans","Payouts","Dashboard","Register"]},
              {t:"Legal",   ls:["Terms & Conditions","Privacy Policy","Risk Disclosure","Compliance"]},
              {t:"Support", ls:["Help Center","Live Chat","Email Support","Phone Support"]},
            ].map(({t,ls})=>(
              <div key={t}>
                <div style={{fontFamily:"var(--ff-s)",letterSpacing:3,fontSize:12,color:"var(--red)",marginBottom:14}}>{t}</div>
                <div style={{display:"flex",flexDirection:"column",gap:10}}>
                  {ls.map(l=><a key={l} href="#" style={{color:"var(--fg2)",textDecoration:"none",fontSize:13,transition:"color .2s"}} onMouseEnter={e=>e.currentTarget.style.color="var(--fg)"} onMouseLeave={e=>e.currentTarget.style.color=""}>{l}</a>)}
                </div>
              </div>
            ))}
          </div>
          <div style={{borderTop:"1px solid var(--bdr)",paddingTop:18,display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"}}>
            <div style={{color:"var(--fg2)",fontSize:12}}>© 2026 Vexora Capital Ltd. All rights reserved.</div>
            <div style={{color:"var(--fg2)",fontSize:11,lineHeight:1.5}}>Investment involves risk. Capital may be at risk.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function AboutPage({setPage}){
  return(
    <section style={{position:"relative",padding:"clamp(60px,8vw,100px) clamp(16px,5vw,60px) 80px",overflow:"hidden",minHeight:"calc(100vh - 70px)"}}>
      <Particles/>
      <div className="mesh"/>
      <div style={{maxWidth:1100,margin:"0 auto",position:"relative",zIndex:1}}>
        <div style={{animation:"fadeUp .8s ease both"}}>
          <div className="sec-label" style={{marginBottom:14}}>◈ Our Story</div>
          <h1 className="sec-title" style={{fontSize:"clamp(34px,5vw,56px)",marginBottom:20}}>The Future of <em>Global</em><br/>Investment</h1>
          <p style={{color:"var(--fg2)",fontSize:16,lineHeight:1.85,maxWidth:640,marginBottom:40}}>Vexora Capital was founded with a singular mission: to democratize access to premium investment opportunities once reserved only for institutional players and ultra-high-net-worth individuals.</p>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,340px),1fr))",gap:"clamp(28px,5vw,48px)",alignItems:"start"}}>
          <div>
            <div style={{fontFamily:"var(--ff-d)",fontWeight:700,fontSize:22,marginBottom:24,color:"var(--gold-l)"}}>Our Journey</div>
            <div className="timeline">
              {[{y:"2019",t:"Founded by veteran investment bankers and fintech engineers with 40+ combined years of experience."},{y:"2020",t:"Launched Beta with 200 early investors. 98% satisfaction rating in year one of operations."},{y:"2021",t:"Expanded to 45 countries. Surpassed $2M in total investor payouts. Referral program launched."},{y:"2022",t:"Introduced Gold, Premium, and Executive tiers. Total payouts exceeded $8M."},{y:"2023",t:"Launched VIP Plan. 15,000+ active investors across 72 countries. ISO 27001 security certified."},{y:"2024",t:"$18M+ total paid out. 24,700+ investors. 89 countries. Top 10 Global Fintech Platform."}].map(({y,t})=>(
                <div key={y} className="tl-item"><div className="tl-dot"/><div className="tl-year">{y}</div><div className="tl-text">{t}</div></div>
              ))}
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div className="card" style={{padding:28}}>
              <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:18}}>OUR MISSION</div>
              <p style={{color:"var(--fg2)",fontSize:14,lineHeight:1.75}}>To provide every investor — regardless of starting capital — with access to high-yield, transparent investment vehicles managed by experienced professionals and powered by cutting-edge financial technology.</p>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
              {[{ic:"🏛",l:"Est. 2019"},{ic:"🌍",l:"89 Countries"},{ic:"👥",l:"24,700+ Investors"},{ic:"💰",l:"$18M+ Paid Out"},{ic:"🔒",l:"ISO 27001 Certified"},{ic:"⭐",l:"4.9/5 Avg Rating"}].map(({ic,l})=>(
                <div key={l} className="card" style={{padding:"16px 18px",display:"flex",alignItems:"center",gap:10}}><span style={{fontSize:18}}>{ic}</span><span style={{fontSize:13,fontWeight:500}}>{l}</span></div>
              ))}
            </div>
            <div className="card" style={{padding:28,textAlign:"center",background:"linear-gradient(135deg,rgba(200,16,46,.1),rgba(200,16,46,.04))"}}>
              <div style={{fontSize:13,color:"var(--fg2)",marginBottom:12}}>Ready to start your investment journey?</div>
              <button className="btn btn-primary btn-full" onClick={()=>setPage("register")}>Create Your Account</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function PlansPage({setPage}){
  return(
    <div style={{position:"relative",padding:"clamp(40px,6vw,80px) clamp(16px,5vw,60px) 60px",minHeight:"calc(100vh - 70px)"}}>
      <div className="mesh"/>
      <div className="grid-lines"/>
      <div style={{maxWidth:1200,margin:"0 auto",position:"relative"}}>
        <div style={{textAlign:"center",marginBottom:56}}>
          <div className="sec-label" style={{marginBottom:14}}>◈ Select Your Tier</div>
          <h1 className="sec-title">Investment <em>Plans</em></h1>
          <p className="sec-sub" style={{maxWidth:520,margin:"12px auto 0"}}>Every plan offers verified, transparent returns. Choose the level that matches your ambition.</p>
        </div>
        <div className="card" style={{padding:"16px clamp(16px,3vw,28px)",marginBottom:28,display:"flex",justifyContent:"space-around",alignItems:"center",flexWrap:"wrap",gap:14}}>
          {[{l:"Minimum Entry",v:"$100"},{l:"Maximum Tier",v:"$5,000"},{l:"Highest Return",v:"$75,300"},{l:"Weekly Payouts",v:"✓"},{l:"Referral Bonus",v:"5%"}].map(({l,v})=>(
            <div key={l} style={{textAlign:"center",flex:"1 1 80px"}}><div style={{fontFamily:"var(--ff-s)",fontSize:"clamp(18px,3vw,22px)",color:"var(--gold-l)"}}>{v}</div><div style={{fontSize:10,color:"var(--fg2)",letterSpacing:1,marginTop:2}}>{l}</div></div>
          ))}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(min(100%,230px),1fr))",gap:14}}>
          {PLANS.map(p=><PlanCard key={p.name} plan={p} onInvest={()=>setPage("register")}/>)}
        </div>
        <div style={{textAlign:"center",marginTop:44}}>
          <p style={{color:"var(--fg2)",fontSize:13,marginBottom:14}}>Not sure which plan? Our advisors are available 24/7.</p>
          <button className="btn btn-secondary" onClick={()=>setPage("home")}>Talk to an Advisor</button>
        </div>
      </div>
    </div>
  );
}

function RegisterPage({setPage,setUser,toast}){
  const [form,setForm]=useState({name:"",email:"",phone:"",username:"",password:"",confirm:"",terms:false});
  const [errors,setErrors]=useState({});
  const [loading,setLoading]=useState(false);
  const [strength,setStrength]=useState(0);
  const checkStr=pw=>{let s=0;if(pw.length>=6)s++;if(pw.length>=10)s++;if(/[A-Z]/.test(pw))s++;if(/[0-9]/.test(pw))s++;if(/[^A-Za-z0-9]/.test(pw))s++;setStrength(s);};
  const validate=()=>{const e={};if(!form.name.trim())e.name="Full name is required";if(!form.email.includes("@"))e.email="Valid email required";if(form.phone.replace(/\D/g,"").length<8)e.phone="Valid phone required";if(form.username.length<3)e.username="Min 3 characters";if(form.password.length<6)e.password="Min 6 characters";if(form.password!==form.confirm)e.confirm="Passwords do not match";if(!form.terms)e.terms="Accept terms to continue";return e;};
  const submit=()=>{const e=validate();if(Object.keys(e).length){setErrors(e);return;}setLoading(true);setTimeout(()=>{setUser({name:form.name,username:form.username,email:form.email,balance:0,deposits:0,earnings:0,referrals:0});toast("Account created! Welcome to Vexora Capital.","success");setPage("dashboard");},2000);};
  const sColor=["","#c8102e","#ff6b00","#ffb400","#00c4a0","#00e676"][strength]||"";
  const sLabel=["","Weak","Fair","Good","Strong","Very Strong"][strength]||"";
  const F=({label,field,type="text",ph})=>(
    <div className="input-group">
      <label className="input-label">{label}</label>
      <input className="input" type={type} placeholder={ph} value={form[field]}
        onChange={e=>{const v=e.target.value;setForm({...form,[field]:v});if(field==="password")checkStr(v);if(errors[field])setErrors({...errors,[field]:undefined});}}/>
      {errors[field]&&<div className="input-err">⚠ {errors[field]}</div>}
    </div>
  );
  return(
    <div style={{minHeight:"calc(100vh - 70px)",display:"flex",alignItems:"center",justifyContent:"center",padding:"60px 20px",position:"relative"}}>
      <div className="mesh"/><div className="grid-lines"/>
      <div style={{width:"100%",maxWidth:520,position:"relative",zIndex:1}}>
        <div style={{textAlign:"center",marginBottom:28}}><Logo onClick={()=>setPage("home")}/></div>
        <div className="card" style={{padding:"40px 38px"}}>
          <div style={{textAlign:"center",marginBottom:28}}>
            <div className="sec-label" style={{marginBottom:8}}>◈ Create Account</div>
            <h2 className="sec-title" style={{fontSize:28}}>Start <em>Investing</em> Today</h2>
            <p style={{color:"var(--fg2)",fontSize:13,marginTop:8}}>Join 24,700+ investors worldwide</p>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <F label="FULL NAME" field="name" ph="John Anderson"/>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,200px),1fr))",gap:12}}>
              <F label="EMAIL ADDRESS" field="email" type="email" ph="john@email.com"/>
              <F label="PHONE NUMBER" field="phone" type="tel" ph="+1 234 567 8900"/>
            </div>
            <F label="USERNAME" field="username" ph="john_anderson"/>
            <div>
              <div className="input-group">
                <label className="input-label">PASSWORD</label>
                <input className="input" type="password" placeholder="Minimum 6 characters" value={form.password}
                  onChange={e=>{const v=e.target.value;setForm({...form,password:v});checkStr(v);if(errors.password)setErrors({...errors,password:undefined});}}/>
                {errors.password&&<div className="input-err">⚠ {errors.password}</div>}
              </div>
              {form.password&&(
                <div style={{marginTop:6,display:"flex",alignItems:"center",gap:8}}>
                  <div style={{flex:1,height:2,background:"rgba(255,255,255,.06)",borderRadius:1,overflow:"hidden"}}>
                    <div style={{height:"100%",width:`${(strength/5)*100}%`,background:sColor,borderRadius:1,transition:"all .3s"}}/>
                  </div>
                  <span style={{fontSize:10,color:sColor,letterSpacing:1,minWidth:60}}>{sLabel}</span>
                </div>
              )}
            </div>
            <F label="CONFIRM PASSWORD" field="confirm" type="password" ph="Re-enter password"/>
            <div style={{display:"flex",alignItems:"flex-start",gap:10}}>
              <input type="checkbox" id="terms" checked={form.terms} onChange={e=>setForm({...form,terms:e.target.checked})} style={{marginTop:3,accentColor:"var(--red)",cursor:"pointer",flexShrink:0}}/>
              <label htmlFor="terms" style={{fontSize:13,color:"var(--fg2)",lineHeight:1.5,cursor:"pointer"}}>I agree to the <span style={{color:"var(--red)"}}>Terms & Conditions</span>, <span style={{color:"var(--red)"}}>Privacy Policy</span>, and <span style={{color:"var(--red)"}}>Risk Disclosure</span></label>
            </div>
            {errors.terms&&<div className="input-err">⚠ {errors.terms}</div>}
            <button className="btn btn-primary btn-full" onClick={submit} disabled={loading} style={{padding:"15px",fontSize:14,marginTop:6}}>
              {loading?<><span className="spinner"/>&nbsp;&nbsp;Creating your account…</>:"Create Account & Start Investing →"}
            </button>
          </div>
          <div style={{textAlign:"center",marginTop:20,fontSize:13,color:"var(--fg2)"}}>Already have an account? <span style={{color:"var(--red)",cursor:"pointer",fontWeight:600}} onClick={()=>setPage("login")}>Sign In</span></div>
        </div>
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginTop:16,fontSize:12,color:"var(--fg2)"}}>🔒 256-bit SSL &nbsp;·&nbsp; 🛡 Bank-grade security &nbsp;·&nbsp; ✓ No hidden fees</div>
      </div>
    </div>
  );
}

function LoginPage({setPage,setUser,toast}){
  const [form,setForm]=useState({email:"",password:""});
  const [loading,setLoading]=useState(false);
  const [err,setErr]=useState("");
  const go=()=>{if(!form.email||!form.password){setErr("Please enter your email and password.");return;}setLoading(true);setErr("");setTimeout(()=>{setUser({name:"Demo Investor",username:"demo_investor",email:form.email,balance:12840,deposits:2000,earnings:10840,referrals:3});toast("Welcome back! Signed in successfully.","success");setPage("dashboard");},1600);};
  return(
    <div style={{minHeight:"calc(100vh - 70px)",display:"flex",alignItems:"center",justifyContent:"center",padding:"60px 20px",position:"relative"}}>
      <div className="mesh"/><div className="grid-lines"/>
      <div style={{width:"100%",maxWidth:440,position:"relative",zIndex:1}}>
        <div style={{textAlign:"center",marginBottom:28}}><Logo onClick={()=>setPage("home")}/></div>
        <div className="card" style={{padding:"40px 36px"}}>
          <div style={{textAlign:"center",marginBottom:28}}>
            <div className="sec-label" style={{marginBottom:8}}>◈ Investor Portal</div>
            <h2 className="sec-title" style={{fontSize:28}}>Welcome <em>Back</em></h2>
            <p style={{color:"var(--fg2)",fontSize:13,marginTop:8}}>Sign in to your dashboard</p>
          </div>
          {err&&<div style={{background:"rgba(200,16,46,.08)",border:"1px solid rgba(200,16,46,.3)",borderRadius:8,padding:"11px 14px",fontSize:13,color:"var(--red-b)",marginBottom:16}}>⚠ {err}</div>}
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <div className="input-group"><label className="input-label">EMAIL ADDRESS</label><input className="input" type="email" placeholder="john@email.com" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></div>
            <div className="input-group">
              <label className="input-label">PASSWORD</label>
              <input className="input" type="password" placeholder="••••••••" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} onKeyDown={e=>e.key==="Enter"&&go()}/>
              <div style={{textAlign:"right",marginTop:5}}><span style={{fontSize:12,color:"var(--red)",cursor:"pointer"}}>Forgot password?</span></div>
            </div>
            <button className="btn btn-primary btn-full" onClick={go} disabled={loading} style={{padding:"15px",fontSize:14,marginTop:4}}>
              {loading?<><span className="spinner"/>&nbsp;&nbsp;Signing in…</>:"Sign In →"}
            </button>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12,margin:"18px 0"}}><div style={{flex:1,height:1,background:"var(--bdr)"}}/><span style={{fontSize:12,color:"var(--fg2)"}}>OR</span><div style={{flex:1,height:1,background:"var(--bdr)"}}/></div>
          <button className="btn btn-ghost btn-full" onClick={()=>{setUser({name:"Demo Investor",username:"demo",email:"demo@vexora.com",balance:12840,deposits:2000,earnings:10840,referrals:3});toast("Signed in as Demo Investor","info");setPage("dashboard");}} style={{fontSize:13}}>Try Demo Account</button>
          <div style={{textAlign:"center",marginTop:20,fontSize:13,color:"var(--fg2)"}}>Don't have an account? <span style={{color:"var(--red)",cursor:"pointer",fontWeight:600}} onClick={()=>setPage("register")}>Create one free →</span></div>
        </div>
      </div>
    </div>
  );
}

function PayoutsPage(){
  const [filter,setFilter]=useState("all");
  const shown=filter==="all"?PAYOUTS:PAYOUTS.filter(p=>p.s===filter);
  const totalPaid=PAYOUTS.filter(p=>p.s==="paid").reduce((_,p)=>_+parseFloat(p.rcv.replace(/[$,]/g,"")),0);
  return(
    <div style={{minHeight:"calc(100vh - 70px)",padding:"clamp(40px,6vw,72px) clamp(16px,5vw,60px) 60px",position:"relative"}}>
      <div className="mesh"/><div className="grid-lines"/>
      <div style={{maxWidth:1100,margin:"0 auto",position:"relative"}}>
        <div style={{textAlign:"center",marginBottom:52}}>
          <div className="sec-label" style={{marginBottom:12}}>◈ Verified Transactions</div>
          <h1 className="sec-title">Latest Weekly <em>Payouts</em></h1>
          <p className="sec-sub">Updated daily · All payments verified and processed through secure channels</p>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,160px),1fr))",gap:12,marginBottom:28}}>
          {[{l:"Total Paid This Week",v:`$${totalPaid.toLocaleString()}`,c:"var(--green)"},{l:"Payments Completed",v:PAYOUTS.filter(p=>p.s==="paid").length,c:"var(--fg)"},{l:"Pending Payments",v:PAYOUTS.filter(p=>p.s==="pending").length,c:"#ffb400"},{l:"Countries This Week",v:"12",c:"var(--gold-l)"}].map(({l,v,c})=>(
            <div key={l} className="card" style={{padding:"20px 22px",textAlign:"center"}}><div style={{fontFamily:"var(--ff-s)",fontSize:26,color:c,marginBottom:4,lineHeight:1}}>{v}</div><div style={{fontSize:11,color:"var(--fg2)",letterSpacing:1}}>{l}</div></div>
          ))}
        </div>
        <div className="card" style={{overflow:"hidden"}}>
          <div style={{padding:"18px 22px",borderBottom:"1px solid var(--bdr)",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <div style={{fontFamily:"var(--ff-s)",letterSpacing:3,fontSize:13,color:"var(--red)"}}>PAYOUT RECORDS</div>
              <div style={{display:"flex",alignItems:"center",gap:6,fontSize:12,color:"var(--green)"}}><div style={{width:7,height:7,borderRadius:"50%",background:"var(--green)",animation:"pulseGreen 1.4s ease infinite"}}/>Live Feed</div>
            </div>
            <div style={{display:"flex",gap:6}}>
              {["all","paid","pending"].map(f=><button key={f} className={`btn btn-xs ${filter===f?"btn-primary":"btn-ghost"}`} onClick={()=>setFilter(f)}>{f==="all"?"All":f==="paid"?"Paid":"Pending"}</button>)}
            </div>
          </div>
          <div style={{overflowX:"auto"}}>
            <table className="tbl">
              <thead><tr><th>#</th><th>Investor</th><th>Country</th><th>Plan Invested</th><th>Amount Received</th><th>Payment Date</th><th>Status</th></tr></thead>
              <tbody>
                {shown.map((p,i)=>(
                  <tr key={i}>
                    <td style={{color:"rgba(245,245,240,.3)",fontSize:12}}>{String(i+1).padStart(2,"0")}</td>
                    <td style={{color:"var(--fg)",fontWeight:500}}>{p.name}</td>
                    <td>{p.country}</td>
                    <td style={{color:"var(--fg2)"}}>{p.inv}</td>
                    <td style={{color:"var(--green)",fontWeight:700}}>{p.rcv}</td>
                    <td style={{color:"var(--fg2)",fontSize:13}}>{p.date}</td>
                    <td><span className={`badge ${p.s==="paid"?"b-paid":"b-pend"}`}>● {p.s==="paid"?"Paid":"Pending"}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{padding:"14px 22px",borderTop:"1px solid var(--bdr)",display:"flex",justifyContent:"space-between",fontSize:12,color:"var(--fg2)"}}>
            <span>Showing {shown.length} of {PAYOUTS.length} records</span>
            <span>Investor names masked for privacy</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Dashboard({user,setPage,setUser,toast}){
  const [tab,setTab]=useState("overview");
  const [showDep,setShowDep]=useState(false);
  const [showWd,setShowWd]=useState(false);
  const [notifs,setNotifs]=useState(2);
  const u=user||{name:"Demo Investor",username:"demo_investor",email:"demo@vexora.com",balance:12840,deposits:2000,earnings:10840,referrals:3};
  const inv=[{p:"Gold Plan",inv:700,earn:8400,s:"completed",d:"May 28"},{p:"Silver Plan",inv:500,earn:6000,s:"active",d:"Jun 01"},{p:"Starter Plan",inv:100,earn:1500,s:"completed",d:"May 10"},{p:"Bronze Plan",inv:300,earn:3600,s:"completed",d:"Apr 28"}];
  const wds=[{amt:8400,m:"Bank Transfer",d:"May 30",s:"paid"},{amt:1500,m:"Crypto Wallet",d:"May 14",s:"paid"},{amt:3600,m:"Bitcoin (BTC)",d:"Apr 30",s:"paid"}];
  const sidebar=[{ic:"⬛",l:"Overview",k:"overview"},{ic:"📊",l:"Portfolio",k:"portfolio"},{ic:"💳",l:"Investments",k:"investments"},{ic:"💸",l:"Withdrawals",k:"withdrawals"},{ic:"👥",l:"Referrals",k:"referral"},{ic:"🔔",l:"Notifications",k:"notifications",badge:notifs},{ic:"⚙",l:"Settings",k:"settings"}];
  return(
    <>
      {showDep&&<DepositModal onClose={()=>setShowDep(false)} onSuccess={p=>{toast(`${p} Plan submitted! Your deposit is being processed.`,"success");}}/>}
      {showWd&&<WithdrawModal balance={u.balance} onClose={()=>setShowWd(false)} onSuccess={amt=>{setUser({...u,balance:u.balance-amt});toast(`Withdrawal of $${amt.toLocaleString()} submitted. Arrives in 24–48h.`,"success");}}/>}
      <div className="dash-layout">
        {/* DESKTOP SIDEBAR */}
        <aside className="dash-side">
          <div className="side-hdr">
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
              <div className="avatar" style={{width:36,height:36,fontSize:16}}>{u.name[0]}</div>
              <div><div style={{fontWeight:600,fontSize:13}}>{u.name}</div><div style={{fontSize:11,color:"var(--fg2)"}}>@{u.username}</div></div>
            </div>
            <div style={{marginTop:10}}><span className="pill pill-g" style={{fontSize:10}}>● Active Investor</span></div>
          </div>
          {sidebar.map(({ic,l,k,badge})=>(
            <div key={k} className={`side-item${tab===k?" active":""}`} onClick={()=>{setTab(k);if(k==="notifications")setNotifs(0);}}>
              <span className="ico">{ic}</span><span>{l}</span>
              {badge?<span className="side-badge">{badge}</span>:null}
            </div>
          ))}
          <div style={{marginTop:"auto",padding:"20px"}}>
            <button className="btn btn-ghost" style={{width:"100%",fontSize:12,justifyContent:"center"}} onClick={()=>setPage("home")}>← Back to Site</button>
          </div>
        </aside>
        <main className="dash-main">
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24,flexWrap:"wrap",gap:12}}>
            <div><div style={{fontSize:11,letterSpacing:2,color:"var(--fg2)",marginBottom:4}}>DASHBOARD</div><h2 style={{fontFamily:"var(--ff-d)",fontWeight:700,fontSize:"clamp(20px,4vw,24px)"}}>{tab.charAt(0).toUpperCase()+tab.slice(1)}</h2></div>
            <div style={{display:"flex",gap:8}}>
              <button className="btn btn-primary btn-sm" onClick={()=>setShowDep(true)}>+ Deposit</button>
              <button className="btn btn-secondary btn-sm" onClick={()=>setShowWd(true)}>Withdraw</button>
            </div>
          </div>

          {tab==="overview"&&(
            <>
              <div className="stat-grid">
                {[{l:"Account Balance",ic:"💰",v:`$${u.balance.toLocaleString()}`,c:"var(--green)",ch:"+12.4% this week"},{l:"Total Deposits",ic:"📥",v:`$${u.deposits.toLocaleString()}`,c:"var(--fg)",ch:"2 deposits"},{l:"Total Earnings",ic:"📈",v:`$${u.earnings.toLocaleString()}`,c:"var(--gold-l)",ch:"+542% ROI"},{l:"Active Plans",ic:"⚡",v:"1",c:"var(--red-b)",ch:"Silver Plan"}].map(({l,ic,v,c,ch})=>(
                  <div key={l} className="stat-card"><div className="sc-label"><span>{ic}</span>{l}</div><div className="sc-val" style={{color:c}}>{v}</div><div className="sc-chg"><span style={{fontSize:10}}>◈</span>{ch}</div></div>
                ))}
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,300px),1fr))",gap:16,marginBottom:18}}>
                <div className="card" style={{padding:"24px 26px"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                    <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)"}}>PORTFOLIO PERFORMANCE</div>
                    <span className="pill pill-g">↑ +542%</span>
                  </div>
                  <GrowthChart w={400} h={150}/>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginTop:16}}>
                    {[{l:"7D Return",v:"+$1,240"},{l:"30D Return",v:"+$4,820"},{l:"All Time",v:"+$10,840"}].map(({l,v})=>(
                      <div key={l} style={{textAlign:"center",background:"rgba(255,255,255,.02)",borderRadius:8,padding:"10px 12px"}}>
                        <div style={{fontSize:11,color:"var(--fg2)",marginBottom:3}}>{l}</div>
                        <div style={{fontFamily:"var(--ff-s)",fontSize:18,color:"var(--green)"}}>{v}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="card" style={{padding:"24px 26px"}}>
                  <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:16}}>PLAN DISTRIBUTION</div>
                  <div style={{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:18}}>
                    <DonutChart pct={72}/>
                    <div style={{fontSize:12,color:"var(--fg2)",marginTop:8}}>72% of target reached</div>
                  </div>
                  <div style={{display:"flex",flexDirection:"column",gap:10}}>
                    {[{l:"Silver Plan",p:45,c:"var(--red)"},{l:"Completed",p:55,c:"var(--green)"}].map(({l,p,c})=>(
                      <div key={l}><div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:4}}><span style={{color:"var(--fg2)"}}>{l}</span><span style={{color:c,fontWeight:600}}>{p}%</span></div><div className="prog-track"><div className="prog-fill" style={{width:`${p}%`,background:c==="var(--green)"?"linear-gradient(90deg,#00a854,#00e676)":""}}/></div></div>
                    ))}
                  </div>
                  <div style={{marginTop:18,display:"flex",flexDirection:"column",gap:8}}>
                    <button className="btn btn-primary btn-sm btn-full" onClick={()=>setShowDep(true)}>+ New Investment</button>
                    <button className="btn btn-ghost btn-sm btn-full" onClick={()=>setPage("plans")}>Browse Plans</button>
                  </div>
                </div>
              </div>
              <div className="card" style={{overflow:"hidden"}}>
                <div style={{padding:"16px 22px",borderBottom:"1px solid var(--bdr)",fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)"}}>RECENT ACTIVITY</div>
                <table className="tbl">
                  <thead><tr><th>Plan</th><th>Invested</th><th>Earned</th><th>Date</th><th>Status</th></tr></thead>
                  <tbody>
                    {inv.slice(0,3).map((r,i)=>(
                      <tr key={i}>
                        <td style={{color:"var(--fg)",fontWeight:500}}>{r.p}</td>
                        <td>${r.inv.toLocaleString()}</td>
                        <td style={{color:"var(--green)",fontWeight:600}}>+${r.earn.toLocaleString()}</td>
                        <td>{r.d}</td>
                        <td><span className={`badge ${r.s==="completed"?"b-paid":r.s==="active"?"b-active":"b-pend"}`}>● {r.s}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {tab==="portfolio"&&(
            <div style={{display:"flex",flexDirection:"column",gap:18}}>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,280px),1fr))",gap:16}}>
                <div className="card" style={{padding:"24px 26px"}}>
                  <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:16}}>GROWTH CHART — 6 MONTHS</div>
                  <GrowthChart w={360} h={160}/>
                </div>
                <div className="card" style={{padding:"24px 26px"}}>
                  <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:16}}>PORTFOLIO SNAPSHOT</div>
                  <div style={{display:"flex",flexDirection:"column",gap:14}}>
                    {[{l:"Total Invested",v:`$${u.deposits.toLocaleString()}`,c:"var(--fg)"},{l:"Total Earned",v:`$${u.earnings.toLocaleString()}`,c:"var(--green)"},{l:"Current Balance",v:`$${u.balance.toLocaleString()}`,c:"var(--gold-l)"},{l:"ROI",v:"+542%",c:"var(--green)"},{l:"Active Plans",v:"1",c:"var(--fg)"},{l:"Completed Plans",v:"3",c:"var(--fg)"}].map(({l,v,c})=>(
                      <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"10px 0",borderBottom:"1px solid var(--bdr)"}}>
                        <span style={{fontSize:13,color:"var(--fg2)"}}>{l}</span>
                        <span style={{fontFamily:"var(--ff-s)",fontSize:18,color:c}}>{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="card" style={{padding:"24px 26px"}}>
                <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:16}}>QUICK INVEST</div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:14}}>
                  {PLANS.slice(0,4).map(p=>(
                    <div key={p.name} style={{background:"rgba(200,16,46,.05)",border:"1px solid var(--bdr)",borderRadius:10,padding:"16px 18px",cursor:"pointer",transition:"all .25s"}}
                      onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(200,16,46,.5)";e.currentTarget.style.transform="translateY(-3px)";}}
                      onMouseLeave={e=>{e.currentTarget.style.borderColor="";e.currentTarget.style.transform="";}}>
                      <div style={{fontFamily:"var(--ff-s)",fontSize:16,marginBottom:4}}>{p.name}</div>
                      <div style={{fontSize:12,color:"var(--fg2)",marginBottom:8}}>Invest ${p.invest.toLocaleString()}</div>
                      <div style={{fontFamily:"var(--ff-s)",fontSize:20,color:"var(--green)"}}>+${p.earn.toLocaleString()}</div>
                      <button className="btn btn-primary btn-xs" style={{marginTop:12,width:"100%"}} onClick={()=>setShowDep(true)}>Select</button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab==="investments"&&(
            <div className="card" style={{overflow:"hidden"}}>
              <div style={{padding:"16px 22px",borderBottom:"1px solid var(--bdr)",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)"}}>INVESTMENT HISTORY</div>
                <button className="btn btn-primary btn-xs" onClick={()=>setShowDep(true)}>+ New Investment</button>
              </div>
              <table className="tbl">
                <thead><tr><th>#</th><th>Plan</th><th>Invested</th><th>Earned</th><th>Start Date</th><th>Status</th></tr></thead>
                <tbody>
                  {inv.map((r,i)=>(
                    <tr key={i}>
                      <td style={{color:"rgba(245,245,240,.3)",fontSize:11}}>{String(i+1).padStart(2,"0")}</td>
                      <td style={{color:"var(--fg)",fontWeight:600}}>{r.p}</td>
                      <td>${r.inv.toLocaleString()}</td>
                      <td style={{color:"var(--green)",fontWeight:700}}>+${r.earn.toLocaleString()}</td>
                      <td style={{color:"var(--fg2)"}}>{r.d}, 2026</td>
                      <td><span className={`badge ${r.s==="completed"?"b-paid":r.s==="active"?"b-active":"b-pend"}`}>● {r.s}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {tab==="withdrawals"&&(
            <div style={{display:"flex",flexDirection:"column",gap:16}}>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,160px),1fr))",gap:12}}>
                {[{l:"Total Withdrawn",v:`$${wds.reduce((a,w)=>a+w.amt,0).toLocaleString()}`,c:"var(--fg)"},{l:"Withdrawals Made",v:wds.length,c:"var(--fg)"},{l:"Available Balance",v:`$${u.balance.toLocaleString()}`,c:"var(--green)"}].map(({l,v,c})=>(
                  <div key={l} className="card" style={{padding:"20px 22px",textAlign:"center"}}><div style={{fontFamily:"var(--ff-s)",fontSize:26,color:c,marginBottom:4}}>{v}</div><div style={{fontSize:11,color:"var(--fg2)",letterSpacing:1}}>{l}</div></div>
                ))}
              </div>
              <div className="card" style={{overflow:"hidden"}}>
                <div style={{padding:"16px 22px",borderBottom:"1px solid var(--bdr)",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)"}}>WITHDRAWAL HISTORY</div>
                  <button className="btn btn-primary btn-xs" onClick={()=>setShowWd(true)}>New Withdrawal</button>
                </div>
                <table className="tbl">
                  <thead><tr><th>#</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th></tr></thead>
                  <tbody>
                    {wds.map((r,i)=>(
                      <tr key={i}>
                        <td style={{color:"rgba(245,245,240,.3)",fontSize:11}}>{String(i+1).padStart(2,"0")}</td>
                        <td style={{color:"var(--green)",fontWeight:700}}>${r.amt.toLocaleString()}</td>
                        <td>{r.m}</td>
                        <td>{r.d}, 2026</td>
                        <td><span className="badge b-paid">● {r.s}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab==="referral"&&(
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,280px),1fr))",gap:16}}>
              <div className="card" style={{padding:28}}>
                <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:18}}>YOUR REFERRAL PROGRAM</div>
                <div style={{background:"linear-gradient(135deg,rgba(200,16,46,.08),rgba(200,16,46,.03))",border:"1px solid var(--bdr)",borderRadius:10,padding:"18px 20px",marginBottom:18}}>
                  <div style={{fontSize:12,color:"var(--fg2)",marginBottom:4}}>Your Commission Rate</div>
                  <div style={{fontFamily:"var(--ff-s)",fontSize:40,color:"var(--gold-l)"}}>5%</div>
                  <div style={{fontSize:12,color:"var(--fg2)",marginTop:2}}>on every investment by your referrals</div>
                </div>
                <div style={{marginBottom:16}}>
                  <label className="input-label">YOUR REFERRAL LINK</label>
                  <div className="ref-link">https://vexoracapital.com/ref/{u.username}</div>
                </div>
                <div style={{display:"flex",gap:10}}>
                  <button className="btn btn-primary btn-sm" style={{flex:1}} onClick={()=>toast("Referral link copied to clipboard!","success")}>Copy Link</button>
                  <button className="btn btn-ghost btn-sm" style={{flex:1}}>Share</button>
                </div>
              </div>
              <div className="card" style={{padding:28}}>
                <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:18}}>REFERRAL STATS</div>
                {[{l:"Total Referrals",v:u.referrals||0},{l:"Active Referrals",v:u.referrals||0},{l:"Referral Earnings",v:"$0.00"},{l:"Pending Commissions",v:"$0.00"},{l:"Paid Commissions",v:"$0.00"}].map(({l,v})=>(
                  <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"11px 0",borderBottom:"1px solid var(--bdr)"}}>
                    <span style={{fontSize:13,color:"var(--fg2)"}}>{l}</span>
                    <span style={{fontFamily:"var(--ff-s)",fontSize:18}}>{v}</span>
                  </div>
                ))}
                <div style={{marginTop:20,background:"rgba(0,230,118,.06)",border:"1px solid rgba(0,230,118,.15)",borderRadius:9,padding:"13px 16px",fontSize:13,color:"var(--fg2)",lineHeight:1.6}}>
                  💡 Share your link to earn commissions. Payments are instant once your referral invests.
                </div>
              </div>
            </div>
          )}

          {tab==="notifications"&&(
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              {[{ic:"✅",msg:"Your Silver Plan is currently active. Returns will be credited on Jun 08, 2026.",time:"2h ago",unread:true},{ic:"💰",msg:"Gold Plan return of $8,400 has been credited to your balance.",time:"8d ago",unread:true},{ic:"🎉",msg:"Welcome to Vexora Capital! Your account is fully verified and ready to invest.",time:"30d ago",unread:false}].map((n,i)=>(
                <div key={i} className="card" style={{padding:"18px 22px",display:"flex",gap:14,alignItems:"flex-start",borderColor:n.unread?"rgba(200,16,46,.4)":"var(--bdr)"}}>
                  <div style={{fontSize:22,flexShrink:0}}>{n.ic}</div>
                  <div style={{flex:1}}><div style={{fontSize:14,lineHeight:1.6,marginBottom:4}}>{n.msg}</div><div style={{fontSize:11,color:"var(--fg2)"}}>{n.time}</div></div>
                  {n.unread&&<div style={{width:8,height:8,borderRadius:"50%",background:"var(--red)",flexShrink:0,marginTop:4}}/>}
                </div>
              ))}
            </div>
          )}

          {tab==="settings"&&(
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,280px),1fr))",gap:16}}>
              <div className="card" style={{padding:28}}>
                <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:18}}>ACCOUNT DETAILS</div>
                <div style={{display:"flex",flexDirection:"column",gap:14}}>
                  <div className="input-group"><label className="input-label">FULL NAME</label><input className="input" defaultValue={u.name}/></div>
                  <div className="input-group"><label className="input-label">EMAIL ADDRESS</label><input className="input" defaultValue={u.email}/></div>
                  <div className="input-group"><label className="input-label">USERNAME</label><input className="input" defaultValue={`@${u.username}`}/></div>
                  <button className="btn btn-primary btn-sm" onClick={()=>toast("Profile updated successfully.","success")}>Save Changes</button>
                </div>
              </div>
              <div className="card" style={{padding:28}}>
                <div style={{fontFamily:"var(--ff-s)",letterSpacing:2,fontSize:13,color:"var(--red)",marginBottom:18}}>SECURITY</div>
                <div style={{display:"flex",flexDirection:"column",gap:14}}>
                  <div className="input-group"><label className="input-label">CURRENT PASSWORD</label><input className="input" type="password" placeholder="••••••••"/></div>
                  <div className="input-group"><label className="input-label">NEW PASSWORD</label><input className="input" type="password" placeholder="••••••••"/></div>
                  <div className="input-group"><label className="input-label">CONFIRM NEW PASSWORD</label><input className="input" type="password" placeholder="••••••••"/></div>
                  <button className="btn btn-secondary btn-sm" onClick={()=>toast("Password updated successfully.","success")}>Update Password</button>
                </div>
                <div style={{marginTop:20,paddingTop:20,borderTop:"1px solid var(--bdr)"}}>
                  <div style={{fontSize:13,fontWeight:600,marginBottom:8}}>Two-Factor Authentication</div>
                  <div style={{fontSize:13,color:"var(--fg2)",marginBottom:12}}>Add an extra layer of security to your account.</div>
                  <button className="btn btn-ghost btn-sm" onClick={()=>toast("2FA setup instructions sent to your email.","info")}>Enable 2FA</button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
      {/* MOBILE BOTTOM TAB BAR */}
      <div className="mob-tabs">
        {[{ic:"⬛",l:"Home",k:"overview"},{ic:"💳",l:"Invest",k:"investments"},{ic:"💸",l:"Withdraw",k:"withdrawals"},{ic:"👥",l:"Refer",k:"referral"},{ic:"⚙",l:"Settings",k:"settings"}].map(({ic,l,k})=>(
          <button key={k} className={`mob-tab${tab===k?" active":""}`} onClick={()=>{setTab(k);if(k==="notifications")setNotifs(0);}}>
            <span className="mt-ic">{ic}</span>{l}
          </button>
        ))}
      </div>
    </>
  );
}

export default function App(){
  const [page,setPage]=useState("home");
  const [user,setUser]=useState(null);
  const [scrolled,setScrolled]=useState(false);
  const [drawer,setDrawer]=useState(false);
  const {toasts,add:toast}=useToast();

  useEffect(()=>{const h=()=>setScrolled(window.scrollY>20);window.addEventListener("scroll",h);return()=>window.removeEventListener("scroll",h);},[]);
  useEffect(()=>{window.scrollTo({top:0,behavior:"smooth"});},[page]);

  const navLinks=[{l:"Home",p:"home"},{l:"About",p:"about"},{l:"Plans",p:"plans"},{l:"Payouts",p:"payouts"},{l:"Contact",p:"home"}];
  const go=p=>{setPage(p);setDrawer(false);};

  return(
    <>
      <GlobalStyle/>
      <ToastStack toasts={toasts}/>

      <nav className={scrolled?"nav-scrolled":""}>
        <Logo onClick={()=>go("home")}/>
        <ul className="nav-links">
          {navLinks.map(({l,p})=><li key={l}><a href="#" className={page===p?"active":""} onClick={e=>{e.preventDefault();go(p);}}>{l}</a></li>)}
        </ul>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          {user?(
            <div style={{display:"flex",gap:10,alignItems:"center"}}>
              <div style={{display:"flex",alignItems:"center",gap:8,padding:"6px 14px",background:"rgba(200,16,46,.08)",border:"1px solid var(--bdr)",borderRadius:6}}>
                <div className="avatar" style={{width:26,height:26,fontSize:12}}>{user.name[0]}</div>
                <span style={{fontSize:12,fontWeight:500}}>{user.name.split(" ")[0]}</span>
              </div>
              <button className="btn btn-primary btn-sm" onClick={()=>go("dashboard")}>Dashboard</button>
            </div>
          ):(
            <>
              <button className="btn btn-secondary btn-sm" onClick={()=>go("login")}>Sign In</button>
              <button className="btn btn-primary btn-sm" onClick={()=>go("register")}>Get Started</button>
            </>
          )}
        </div>
        <button className="hamburger" onClick={()=>setDrawer(true)}><span/><span/><span/></button>
      </nav>

      {drawer&&(
        <div className="mobile-drawer">
          <div className="drawer-bg" onClick={()=>setDrawer(false)}/>
          <div className="drawer-panel">
            <Logo onClick={()=>go("home")}/>
            <div className="drawer-links">
              {navLinks.map(({l,p})=><a key={l} href="#" onClick={e=>{e.preventDefault();go(p);}}>{l}</a>)}
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:10,marginTop:"auto"}}>
              {user?(
                <button className="btn btn-primary btn-full" onClick={()=>go("dashboard")}>Dashboard</button>
              ):(
                <>
                  <button className="btn btn-secondary btn-full" onClick={()=>go("login")}>Sign In</button>
                  <button className="btn btn-primary btn-full" onClick={()=>go("register")}>Get Started</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      <main style={{paddingTop:"var(--nav)"}}>
        {page==="home"     && <LandingPage  setPage={go}/>}
        {page==="about"    && <AboutPage    setPage={go}/>}
        {page==="plans"    && <PlansPage    setPage={go}/>}
        {page==="payouts"  && <PayoutsPage/>}
        {page==="login"    && <LoginPage    setPage={go} setUser={setUser} toast={toast}/>}
        {page==="register" && <RegisterPage setPage={go} setUser={setUser} toast={toast}/>}
        {page==="dashboard"&& <Dashboard    user={user} setPage={go} setUser={setUser} toast={toast}/>}
      </main>
    </>
  );
}
