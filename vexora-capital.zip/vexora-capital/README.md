# Vexora Capital — Premium Investment Platform

A full-featured investment platform built with React + Vite, ready to deploy on Vercel in minutes.

---

## 🚀 Deploy to Vercel (3 ways)

### Option 1 — Vercel CLI (fastest)
```bash
# 1. Install dependencies
npm install

# 2. Install Vercel CLI (if not already)
npm i -g vercel

# 3. Deploy
vercel

# Follow the prompts — Vercel auto-detects Vite.
# Your site will be live at https://your-project.vercel.app
```

### Option 2 — GitHub + Vercel Dashboard
1. Push this folder to a GitHub repository
2. Go to [vercel.com](https://vercel.com) → **New Project**
3. Import your GitHub repo
4. Vercel auto-detects the framework as **Vite**
5. Click **Deploy** — done ✅

### Option 3 — Drag & Drop (no Git needed)
1. Run `npm install && npm run build` locally
2. Go to [vercel.com/new](https://vercel.com/new)
3. Drag the `dist/` folder onto the page
4. Done — live in seconds

---

## 🛠 Local Development

```bash
# Install dependencies
npm install

# Start dev server (hot reload)
npm run dev
# → http://localhost:5173

# Build for production
npm run build

# Preview production build locally
npm run preview
```

---

## 📁 Project Structure

```
vexora-capital/
├── public/
│   └── favicon.svg          # Brand favicon
├── src/
│   ├── App.jsx              # Full platform (all pages + components)
│   └── main.jsx             # React entry point
├── index.html               # HTML shell
├── vite.config.js           # Vite configuration
├── vercel.json              # Vercel SPA routing rules
├── package.json
└── .gitignore
```

---

## ⚙️ Build Settings (auto-detected by Vercel)

| Setting | Value |
|---|---|
| Framework | Vite |
| Build Command | `npm run build` |
| Output Directory | `dist` |
| Install Command | `npm install` |
| Node.js Version | 18.x or 20.x |

---

## 🌐 Pages Included

| Page | Route (client-side) |
|---|---|
| Landing / Home | `/` |
| About | (tab in app) |
| Investment Plans | (tab in app) |
| Live Payouts | (tab in app) |
| Register | (tab in app) |
| Login | (tab in app) |
| Dashboard | (tab in app) |

All navigation is client-side (SPA). The `vercel.json` rewrites all routes to `/` so deep links and refreshes work correctly.

---

## 📦 Tech Stack

- **React 18** — UI framework
- **Vite 5** — build tool & dev server
- **Pure CSS-in-JS** — no external CSS dependencies
- **Zero UI libraries** — fully custom components

---

## 🔧 Customization

All content is in `src/App.jsx`:

- **PLANS array** (line ~186) — edit plan names, amounts, returns
- **PAYOUTS array** (line ~196) — edit payout records
- **TESTIMONIALS array** (line ~240) — edit investor reviews
- **FAQS array** (line ~223) — edit FAQ content
- **CSS variables** (line ~7) — change `--red`, `--gold`, fonts, etc.

---

Built with ❤️ — Vexora Capital © 2026
